"""
Entry point cPanel's Passenger looks for when you configure
"Setup Python App" with this project's root as the application root.

cPanel sets DJANGO_SETTINGS_MODULE=samwa.settings.prod as an environment
variable in the Python App UI - this file just has to exist and expose
`application`.
"""
import os
import sys

# cPanel's Python App feature usually adds the project root to sys.path
# automatically, but this is a harmless safety net if it doesn't.
sys.path.insert(0, os.path.dirname(__file__))

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "samwa.settings.prod")

from django.core.wsgi import get_wsgi_application  # noqa: E402

application = get_wsgi_application()
